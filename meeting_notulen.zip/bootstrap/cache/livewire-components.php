<?php return array (
  'examination.navigation' => 'App\\Http\\Livewire\\Examination\\Navigation',
  'examination.pager' => 'App\\Http\\Livewire\\Examination\\Pager',
  'examination.soal' => 'App\\Http\\Livewire\\Examination\\Soal',
  'student.keygen' => 'App\\Http\\Livewire\\Student\\Keygen',
  'student.keygen-modal' => 'App\\Http\\Livewire\\Student\\KeygenModal',
);