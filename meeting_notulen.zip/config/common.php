<?php

return [
    'default_password' => '123'
];